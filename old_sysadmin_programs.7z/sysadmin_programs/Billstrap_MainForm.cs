// BillStrap
//
// Michael Adams
// cwolfsheep@yahoo.com
// 11-27-2004
// *. 1-20-2005; posted online; code obscured; waiting form not included
//
// References
//
// 1. http://www.dotnetspider.com/technology/tutorials/CRUDSample.aspx
// 2. Google searches on "C# SqlDataAdapter timeout"
// 3. http://it.maconstate.edu/tutorials/ASPNET/ASPNET14/aspnet14-04.aspx
// 4. http://www.dotnet247.com/247reference/msgs/34/170569.aspx
// 5. http://www.eggheadcafe.com/articles/pfc/selfupdater.asp

using System;
using System.Drawing;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Data.OleDb;
using System.Threading;
using System.Diagnostics;
using System.IO;

namespace Billstrap
{
	/// <summary>
	/// MainForm
	/// </summary>
	public class MainForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button btnLoad;
		private System.Windows.Forms.TextBox tbDBServer;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.NumericUpDown nudTimeout;
		private System.Windows.Forms.TextBox tbDBFilename;
		private System.Windows.Forms.MonthCalendar mcStop;
		private System.Windows.Forms.MonthCalendar mcStart;
		// Constructor
		public MainForm()
		{
			InitializeComponent();
		}
		
		// Static Main: run this program
		[STAThread]
		public static void Main(string[] args)
		{
			Application.Run(new MainForm());
		}
		
		#region Windows Forms Designer generated code
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent() {
			this.mcStart = new System.Windows.Forms.MonthCalendar();
			this.mcStop = new System.Windows.Forms.MonthCalendar();
			this.tbDBFilename = new System.Windows.Forms.TextBox();
			this.nudTimeout = new System.Windows.Forms.NumericUpDown();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.tbDBServer = new System.Windows.Forms.TextBox();
			this.btnLoad = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.nudTimeout)).BeginInit();
			this.SuspendLayout();
			// 
			// mcStart
			// 
			this.mcStart.CalendarDimensions = new System.Drawing.Size(3, 1);
			this.mcStart.Location = new System.Drawing.Point(0, 32);
			this.mcStart.Name = "mcStart";
			this.mcStart.TabIndex = 0;
			// 
			// mcStop
			// 
			this.mcStop.CalendarDimensions = new System.Drawing.Size(3, 1);
			this.mcStop.Location = new System.Drawing.Point(0, 216);
			this.mcStop.Name = "mcStop";
			this.mcStop.TabIndex = 3;
			// 
			// tbDBFilename
			// 
			this.tbDBFilename.Location = new System.Drawing.Point(392, 416);
			this.tbDBFilename.Name = "tbDBFilename";
			this.tbDBFilename.Size = new System.Drawing.Size(128, 20);
			this.tbDBFilename.TabIndex = 7;
			this.tbDBFilename.Text = "Billing.mdb";
			this.tbDBFilename.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// nudTimeout
			// 
			this.nudTimeout.Location = new System.Drawing.Point(448, 384);
			this.nudTimeout.Maximum = new System.Decimal(new int[] {
						360,
						0,
						0,
						0});
			this.nudTimeout.Name = "nudTimeout";
			this.nudTimeout.Size = new System.Drawing.Size(72, 20);
			this.nudTimeout.TabIndex = 5;
			this.nudTimeout.Value = new System.Decimal(new int[] {
						180,
						0,
						0,
						0});
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(280, 416);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(104, 16);
			this.label4.TabIndex = 8;
			this.label4.Text = "D/B to Write";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(280, 448);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(104, 16);
			this.label5.TabIndex = 10;
			this.label5.Text = "D/B Server";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// tbDBServer
			// 
			this.tbDBServer.Location = new System.Drawing.Point(392, 448);
			this.tbDBServer.Name = "tbDBServer";
			this.tbDBServer.Size = new System.Drawing.Size(128, 20);
			this.tbDBServer.TabIndex = 9;
			this.tbDBServer.Text = "ABOL-SERVER";
			this.tbDBServer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// btnLoad
			// 
			this.btnLoad.Location = new System.Drawing.Point(8, 440);
			this.btnLoad.Name = "btnLoad";
			this.btnLoad.Size = new System.Drawing.Size(192, 23);
			this.btnLoad.TabIndex = 4;
			this.btnLoad.Text = "Load Data Into Access Billing";
			this.btnLoad.Click += new System.EventHandler(this.BtnLoadClick);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(200, 8);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(136, 23);
			this.label1.TabIndex = 1;
			this.label1.Text = "Pick date to start billing...";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(200, 192);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(136, 23);
			this.label2.TabIndex = 2;
			this.label2.Text = "Pick date to stop billing...";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(280, 384);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(104, 16);
			this.label3.TabIndex = 6;
			this.label3.Text = "Timeout in Seconds";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(550, 476);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.tbDBServer);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.tbDBFilename);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.nudTimeout);
			this.Controls.Add(this.btnLoad);
			this.Controls.Add(this.mcStop);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.mcStart);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
			this.Name = "MainForm";
			this.Text = "Billstrap";
			((System.ComponentModel.ISupportInitialize)(this.nudTimeout)).EndInit();
			this.ResumeLayout(false);
		}
		#endregion

		
		// Critical Variables
		string dbFilename = "Billing.mdb";
		int timeout = 180;
		
		// Variables
		Process mainprocess = Process.GetCurrentProcess();
		Thread buildThread;
		Thread saveThread;
		Waiting waitform = new Waiting();
		string connStr = "";
		string cmdStr = "";
		SqlDataAdapter sqlAdapter;
		SqlCommand sqlComm;
		SqlConnection sqlConn;
		DataSet sqlSet;
		OleDbConnection oleConn;
		OleDbDataAdapter oleAdapter;
		DataSet oleSet = new DataSet();
		DataRow oleRow;
		OleDbCommandBuilder oleCB;
		
		//--- Table loader: build table from SQL server data ---
		public void buildTable()
		{

		try{
 
 		// Connection parameters
		connStr =
		 "server=" +
		 tbDBServer.Text + 
		 ";uid=sa;pwd=;database=ams_db";

		// Query parameters
		cmdStr =						
		 "Select sh.shipmentnbr,sh.accountnbr,sh.referencenbr,"+
		 "sh.weight,sh.shiptozip,sh.sortcode1,sh.postage,sh.shipdate,"+
		 "sh.shiptime,sh.zone,sh.manifestkey,"+
		 "ma.SHIPDATE,ma.SHIPTIME,ma.ENTRYFACILITYNAME "+
		 "from SHIPMENT sh "+
		 "join MANIFEST ma on sh.manifestkey = ma.id "+
		 "where ma.SHIPDATE > '"+
		 mcStart.SelectionStart.Date.AddDays(-1).ToShortDateString() +
		 "' and ma.SHIPDATE < '"+
		 mcStop.SelectionStart.Date.AddDays(1).ToShortDateString()+
		 "'";
		
		//Build data tables
		sqlConn = new SqlConnection(connStr);
		sqlComm = new SqlCommand(cmdStr,sqlConn);
		sqlComm.CommandTimeout = timeout;
		sqlAdapter = new SqlDataAdapter(sqlComm);
		sqlSet = new DataSet();
		sqlAdapter.Fill(sqlSet,"SHIPMENT");
		
		//Close connection		
		sqlAdapter.Dispose();
		}
		//Catch errors
		catch(Exception e)
		{
		MessageBox.Show(e.ToString(),"Error in reading ABOL Database",MessageBoxButtons.OK);
		}		
		}
		
		//--- Table writer: save table to Access database ---
		public void saveTable()
		{
			try{
			// Show row count
			waitform.lblRows.Text = sqlSet.Tables[0].Rows.Count.ToString();
			// Prepare connection to billing database
			connStr = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source="+dbFilename;
			oleConn = new OleDbConnection(connStr);
			OleDbCommand oleSelect = new OleDbCommand("SELECT * FROM [MASTER TABLE]",oleConn);
			oleAdapter = new OleDbDataAdapter(oleSelect);
			oleConn.Open();
			// Load schema
			oleAdapter.FillSchema(oleSet,SchemaType.Source,"MASTER TABLE");
			oleAdapter.MissingSchemaAction = MissingSchemaAction.AddWithKey;
			// Build commands
			oleCB = new OleDbCommandBuilder(oleAdapter);
			oleCB.QuotePrefix = "[";
			oleCB.QuoteSuffix = "]";
			oleAdapter.InsertCommand = oleCB.GetInsertCommand();
			oleAdapter.UpdateCommand = oleCB.GetUpdateCommand();
			// Fill table
			oleAdapter.Fill(oleSet,"MASTER TABLE");
								
			// Loop through each record & write it
			foreach(DataRow datarow in sqlSet.Tables[0].Rows){
				 	 
			// Make new Access row
			oleRow = oleSet.Tables["MASTER TABLE"].NewRow();
			oleRow["UniqueShipment"] = System.Convert.ToInt32(datarow[0]);
			oleRow["Company Identifier"] = datarow[1];
			oleRow["Package ID"] = datarow[2];
			oleRow["Weight"] = System.Convert.ToDouble(datarow[3]);
			oleRow["Customer Zip"] = datarow[4];
			oleRow["Route"] = datarow[5];
			oleRow["Postage"] = System.Convert.ToDouble(datarow[6]);
			oleRow["Date Received"] = System.Convert.ToDateTime(DateTime.Parse(System.Convert.ToString(datarow[7]))).ToShortDateString();
			oleRow["Time Received"] = (string)(DateTime.Parse(System.Convert.ToString(oleRow["Date Received"])).ToShortDateString() + " " + System.Convert.ToDateTime(DateTime.Parse(System.Convert.ToString(datarow[8]))).ToShortTimeString());
			oleRow["Date Released"] = System.Convert.ToDateTime(DateTime.Parse(System.Convert.ToString(datarow[11]))).ToShortDateString();
			oleRow["Time Released"] = (string)(DateTime.Parse(System.Convert.ToString(oleRow["Date Released"])).ToShortDateString() + " " + System.Convert.ToDateTime(DateTime.Parse(System.Convert.ToString(datarow[12]))).ToShortTimeString());
			oleRow["DDU"] = datarow[13];
			oleRow["Zone"] = datarow[9];
			oleRow["Zip"] = datarow[4];
			
			// Add row
			oleSet.Tables["MASTER TABLE"].Rows.Add(oleRow);
			waitform.lbLoaded.Items.Add(oleRow["Package ID"]);
			Application.DoEvents();
			}
			//Update & close Access database
			oleAdapter.Update(oleSet,"MASTER TABLE");
			Application.DoEvents();
			oleConn.Close();
			}
			//Catch Errors
			catch(Exception e)
			{
			MessageBox.Show(e.ToString(),"Error in writing Access Database",MessageBoxButtons.OK);
			}
		}
		
		//--- "Load" button ---
		void BtnLoadClick(object sender, System.EventArgs e)
		{
			try{

			// get new variable settings
			dbFilename = tbDBFilename.Text;
			timeout = Int32.Parse(nudTimeout.Text);
				
			// make a new waiting form & thread for it
			buildThread = new Thread(new ThreadStart(buildTable));
			DateTime now = DateTime.Now;
			waitform.Show();
			buildThread.Start();
			//load SQL database
			do{
				waitform.lblTimeout.Text = Convert.ToString(timeout-((DateTime.Now.Ticks - now.Ticks)/10000000));
				Application.DoEvents();
			}while(buildThread.IsAlive);

			//dump table to Access
			saveThread = new Thread(new ThreadStart(saveTable));
			saveThread.Start();
			now = DateTime.Now;
			do{
				waitform.lblDBTime.Text = Convert.ToString((DateTime.Now.Ticks - now.Ticks)/10000000);
				Application.DoEvents();
			}while(saveThread.IsAlive);
			
			// Update window
			waitform.Invalidate();
			Application.DoEvents();
			
			// Make sure threads are dead before running Access
			if(!saveThread.IsAlive)
			if(!buildThread.IsAlive)
			{
				ProcessStartInfo process = new ProcessStartInfo();				
				process.Arguments = Directory.GetCurrentDirectory() + "\\" + dbFilename;
				process.FileName = "C:\\Program Files\\Microsoft Office\\Office\\MSACCESS.EXE";
				Process.Start(process);
			}
				
			}
			//catch errors
			catch(Exception ex)
			{
			MessageBox.Show(ex.ToString(),"Billstrap Error",MessageBoxButtons.OK);				
			}
			//self-destruct to end active threads
			finally
			{
			waitform.Close();
			this.Dispose();
			mainprocess.Kill();				
			}			
		}

	}
}
